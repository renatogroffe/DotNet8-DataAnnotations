# DotNet8-ConsoleApp-AllowedValuesAttribute
Exemplo em .NET 8 de Console Application que faz uso do atributo AllowedValuesAttribute para validar os valores possíveis/permitidos para uma propriedade em uma classe.
