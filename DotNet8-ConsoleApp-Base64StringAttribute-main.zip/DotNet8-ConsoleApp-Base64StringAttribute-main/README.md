# Base64StringAttribute
Exemplo em .NET 8 de Console Application que faz uso do atributo Base64StringAttribute para validar se uma string associada a uma propriedade de uma classe é um valor do tipo base64 válido.
